from multiprocessing import context
from django.shortcuts import render, HttpResponse
from django.shortcuts import render, redirect 
from django.contrib.auth.models import User
# Create your views here.

def sensor(request):
    return render(request, 'base.html')
    # return HttpResponse("this is homepage")
    
def stop(request):
    return render(request,"stop.html")

def delete(request):
    return render(request,"Mdelete.html")

def newd(request):
    return render(request,'bar.html')
    

def newd1(request):
    return render(request,'future.html')

def test(request):
    return render(request,'newcheck.html')

def email1(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.email_user_set.all()
    fault_N=user.email_user_set.count()
    all_user=User.objects.all()
    
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault,'user':user,'Number_fault':fault_N}
    return render(request,"EMAIL.html",conext)

 
 
 
 
 
 
 
 
 
def fault(request):

    return render(request,"fault.html") 
    
def fault_P(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.fault_occur_set.all()
    all_user=User.objects.all()
    
    print("current user",user)
    print("all user",all_user)
    print("all user",fault)
 
    conext={'faults':fault}
    return render(request,"fault1.html",conext)
    

def future_fault(request):
    current=request.user
    id=current.id
    user=User.objects.get(id=id)
    fault=user.fault_future_set.all()
    all_user=User.objects.all()
    
    print("future current user",user)
    print(" future all user",all_user)
    print(" future all user",fault)
 
    conext={'faults':fault}
    return render(request,"fault2.html",conext)